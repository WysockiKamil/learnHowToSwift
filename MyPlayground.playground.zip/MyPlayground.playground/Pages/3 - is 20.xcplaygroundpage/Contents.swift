import Cocoa

// 3. Write a Swift program that accept two integer values and return true if one of them is 20 or if their sum is 20.

func trueIf20(liczba1: Int, liczba2: Int) -> Bool {
    if liczba1 == 20 || liczba2 == 20 || liczba1 + liczba2 == 20 {
        return true
    } else {
        return false
    }
}
print("-------- 3 -------")
print(trueIf20(liczba1: 210, liczba2: 11))
print(trueIf20(liczba1: 20, liczba2: 11))
