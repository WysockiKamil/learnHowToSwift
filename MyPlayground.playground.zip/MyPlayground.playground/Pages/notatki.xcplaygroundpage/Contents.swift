//import Cocoa
//
//var greeting = "Hello, playground"
//
//var name = "Cos tam"
//name = "kosz "
//name = "Kamil"
//
//let komiks = "kaczor "
//
//
//var playerName = "Kazik"
//print(playerName)
//
//playerName = "Staszek"
//print(playerName)
//
//playerName = "Oszołom °"
//print(playerName)
//
//
//print(komiks.count)
//
//
//let kupa = "klocek"
//
//print("To jest \(kupa)")

/* arrays
- nie mozna dodawac liczb do stringow - roznych typow
- przechowuja duzo wartosci i odczytuja je wykorzystujac indeksy (pozycjonowanie?)
 - Array inicjalizujemy
    var przykladowyArray = Array<Int>
    var przykladowyArray = Array<String>
    albo
    var przykladowyArray = [Int]
    var przykladowyArray = [String]
 
 PRZYKLADOWE METODY
 .count - zlicza elementy array
 .remove() - usuwa ostatni albo konkretny .remove(at: 2)
 .removeAll() - usuwa wszystko
 .contains("jakasZawartosc") - zwraca True albo False
 .sorted() - sortuje od A do Z albo do 1 do
 .reversed() - na przyklad:
    let owoce = ["jablko", "arbuz"]
    let owoceReversed = owoce.reversed() - nie zwroci w odwrotnej kolejnosci ALE ZAPAMIETA, ZE MA BYC ODWROTNIE, to optymalizacja
 */

/* DICTIONARY
 - przechowuja duzo wartosci i odczytuja je wykorzystujac klucze, ktore podalismy "key": "value"
 let empoyee = ["name": "Kamil", "surname": "Wysocki", "location": "Poznan"]
 let maMedal = [
    "Kamil": True,
    "Jan: False,
    "Anna": False
    ]
 */


/* SETS
 - przechowuje wiele wartosci ale nie mozemy wybrac kolejnosci
 let names = Set(["Jan", "Anna", "Pawel", "Kasia"])
 PRZYKŁADOWE METODY:
 .insert
 */

/* ENUMS
 - tworzymy wlasne typu uszczegolowiajac zakres akceptowalnych wartosci
 enum Weekday {
    case monday
    case tuesday
    case wednesday
    case thursday
    case friday
 day = Weekday. <- wybieramy opcje z dropdown
 
 enum UIStyle {
    case: light, dark, system
 */

/*FOR Loop
 1...10 <- od 1 do 10 wlacznie
 1..<10 <- od 1 do 9, bez 10
 for _ in 1...12 <---- nie powtarzamy po jakiejs zmiennej
 */

/* WHILE Loop
 
 */
