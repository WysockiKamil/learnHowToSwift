import Cocoa

// 5. Write a Swift program to add "Is" to the front of a given string. However, if the string already begins with "Is", return the given string.

print("-------- 5 -------")

func IsIsAstringPrefix (ciag: String) -> String {
    if ciag.starts(with: "Is") == true {  //z .hasPrefix tez dziala
        return ciag
    } else {
        return "Is \(ciag)"
    }
}

print(IsIsAstringPrefix(ciag: "Isolda"))
print(IsIsAstringPrefix(ciag: "Is a kotek"))
print(IsIsAstringPrefix(ciag: "isolda"))
print(IsIsAstringPrefix(ciag: "kotek"))
