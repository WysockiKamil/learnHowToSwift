//import Cocoa
//
//var odliczanie = 10
//
//while odliczanie > 0 {
//    print("\(odliczanie)")
//    
//    odliczanie -= 1
//}
//var rzut1 = 0
//var rzut2 = 0
//var sumaRzutow = 0
//
//while sumaRzutow < 10 {
//    rzut1 = Int.random(in: 1...6)
//    rzut2 = Int.random(in: 1...6)
//    sumaRzutow = rzut1 + rzut2
//    print("Yay, wypadlo mi: \(sumaRzutow)")
//}
//
//print("Donna mama")

//let imiona = ["Kamil", "Jan", "Anna", "Marek", "Kasia", "Katarzyna"]
//
//for imie in imiona {
//    if imie.hasSuffix("a") == false{
//        print("\(imie) to meskie imie")
//    } else {
//        print("\(imie) to zenskie imie")
//    }
//}

//var imiona = ["Kamil", "Jan", "Anna", "Marek", "Kasia", "Katarzyna"]
//var meskie = [String()]
//var zenskie  = [String()]
//for imie in imiona {
//    if imie.hasSuffix("a") == false{
//        meskie.append(imie)
//    } else {
//        zenskie.append(imie)
//    }
//}
//print("imiona meskie to \(meskie)")
//print("imiona meskie to \(zenskie)")
