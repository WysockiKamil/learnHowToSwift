//import Cocoa
//
//let McDposilki = ["cheesburgera", "hamburgera", "nuggetsy", "frycie"]
//
//for posilek in McDposilki {
//    print("W maczku zjesz \(posilek)")
//}


//for x in 1...12 {
//    print("Tabliczka mnożenia dla \(x)")
//    
//    for y in 1...12 {
//        print("  \(x) x \(y) = \(x * y)")
//    }
//    print()
//}
