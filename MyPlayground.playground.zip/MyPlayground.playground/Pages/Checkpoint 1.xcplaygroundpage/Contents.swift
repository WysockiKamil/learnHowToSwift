//import Cocoa
//
//var celsius = 36.6
//var fahrenheit = 97.8
//
//var fahrenheitFromCelsius = ((celsius * 9) / 5) + 32
//var celsiusFromFahrenheit = ((fahrenheit - 32) * 5 ) / 9
//
//print("Temperatura wynoszaca dokładnie \(celsius)°C wynosi \(fahrenheitFromCelsius)°F")
//print("Temperatura wynoszaca dokładnie \(fahrenheit)°F wynosi \(celsiusFromFahrenheit)°C")

