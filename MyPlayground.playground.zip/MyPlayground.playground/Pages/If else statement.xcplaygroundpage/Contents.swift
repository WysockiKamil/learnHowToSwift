//import Cocoa
//
//let x = 4
//
//if x > 3 {
//    print("Tak, x jest wieksze od 3")
//}

let forecast = Weather.snow


enum Weather {
    case sun, rain, wind, snow, unknown
}

//if forecast == .sun {
//    print("its sunny outside!")
//} else if forecast == .rain {
//    print("Its raining man, halleuya!")
//} else if forecast == .wind {
//    print("Its windy! Wear something warm")
//} else if forecast == .snow {
//    print("School is cancelled!")
//} else {
//    print("Something went wrong...")
//}

//switch forecast {
//case .sun:
//    print("its sunny outside!")
//case .rain:
//    print("Its raining man, halleuya!")
//case .wind:
//    print("Its windy! Wear something warm")
//case .snow:
//    print("School is cancelled!")
//case .unknown:
//    print("Something went wrong...")
//// default: <----- gdy w enum nie ma odpowiedniego case'a
//}
//
//
//// TERNARY CONDITIONAL <--- nie wiem, jakby to po polsku brzmialo? Potrójny warunek?
//let age = 18
//let canDrink = age >= 18 ? "Yes" : "No"
////              W            T      F
////           What? Co       True   False
////Co sprawdzamy, po ? jest jeśli true a po dwokropki, jesli warunek daje NIE
//print(canDrink)
//
//let hour = 16
//print(hour < 12 ? "Jest przed południem" : "Jest po południu")
//
//
//let imiona = ["Kamil", "Karolina", "Mikołaj", "Szymon"]
//let czlonkowieZespolu = imiona.isEmpty ? "W zespole nikogo nie ma" : "Zespol liczy \(imiona.count) członków"
//print(czlonkowieZespolu)
