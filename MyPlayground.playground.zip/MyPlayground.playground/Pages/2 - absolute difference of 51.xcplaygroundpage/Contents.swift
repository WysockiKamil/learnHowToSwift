import Cocoa

// 2. Write a Swift program to compute and return the absolute difference of n and 51, if n is over 51 return double the absolute difference
// absolute difference = wartosc bezwzgledna

func absoluteDifferenceOf51(n: Int) -> Int {
    if n > 51 {
        return abs(n - 51) * 2
    } else {
        return abs(n - 51)
    }
}

print("-------- 2 -------")
print(absoluteDifferenceOf51(n: 52))
print(absoluteDifferenceOf51(n: 50))
