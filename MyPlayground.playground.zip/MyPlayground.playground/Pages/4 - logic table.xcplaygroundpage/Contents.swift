import Cocoa

// 4. Write a Swift program to accept two integer values and return true if one is negative and one is positive. Return true only if both are negative.

func oneOrBothAreNegative(liczba1: Int, liczba2: Int) -> Bool {
    if liczba1 < 0 && liczba2 > 0 {
        return true
    } else if liczba1 > 0 && liczba2 < 0 {
        return true
    } else if liczba1 < 0 && liczba2 < 0 {
        return true
    } else {
        return false
    }
}
print("-------- 4 -------")
print(oneOrBothAreNegative(liczba1: 5, liczba2: 5))
print(oneOrBothAreNegative(liczba1: -5, liczba2: 5))
print(oneOrBothAreNegative(liczba1: 5, liczba2: -5))
print(oneOrBothAreNegative(liczba1: -5, liczba2: -5))
