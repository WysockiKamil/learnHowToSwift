import Cocoa

//1. Write a Swift program to compute the sum of the two integers. If the values are equal return the triple their sum.

func sumOfTwoInt(liczba1: Int, liczba2: Int) -> Int {
    if liczba1 == liczba2 {
        return (liczba1 + liczba2) * 3
    } else {
        return (liczba1 + liczba2)
    }
}
print("-------- 1 -------")
print(sumOfTwoInt(liczba1: 12, liczba2: 12))
print(sumOfTwoInt(liczba1: 11, liczba2: 12))
