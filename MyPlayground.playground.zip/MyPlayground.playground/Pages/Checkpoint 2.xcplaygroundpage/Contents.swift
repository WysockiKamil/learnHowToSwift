//import Cocoa
//
//let names = ["Kamil", "Jan", "Kasia", "Ania", "Kamil", "Ania"]
//print(names.count)
//
////Zmieniamy Array (liste) names na set (zbior) -> w zbiorze każda wartosc bedzie unikalna, nie ma duplikatow
//let names2 = Set(names)
//print(names2.count)
