import Cocoa

func BMIindex(weight: Double, height: Double) -> Double {
    let BMI = weight / (height * height)
    return  BMI
}

print(BMIindex(weight: 87, height: 1.76))
