import Cocoa
//
//func tabliczkaMnozenia(czynnik: Int) {
//    print("Tabliczka mnozenia")
//    for i in 1...10 {
//        print("\(i) * \(czynnik) = \(i * czynnik)")
//    }
//}
//
//tabliczkaMnozenia(czynnik: 5)

func stringLettersComparision(ciag1: String, ciag2: String) -> Bool{
    var ciag1sorted = ciag1.sorted()
    var ciag2sorted = ciag2.sorted()
    return ciag1sorted == ciag2sorted
}

func twierdzeniePitagorasa(a: Double, b: Double) -> Double {
    let sumaKwadratowPrzyprostokatnych = a * a + b * b
    let pierwiastekZc = sqrt(sumaKwadratowPrzyprostokatnych)
    return pierwiastekZc
}

func poleKwadratu(a: Double) -> Double {
    let pole = a * a
    return pole
}
